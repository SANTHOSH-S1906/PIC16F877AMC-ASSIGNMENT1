
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>


#define _XTAL_FREQ 6000000  // crystal frequency 6MZ

void init_config(void)    
{
    TRISD = 0x00;  // OUTPUT MODE
    PORTD = 0x00;  // Consider 8 LED's ARE CONNECT TO PORTD
}

void main(void)
{
    unsigned int delay = 0; //Delay
    unsigned int i = 0;

    init_config();

    while (1) //Super Loop
    {
        
        if (delay++ == 10000) //NON-BLOCKING DELAY
        {
            delay = 0;
            
            // Pattern 1 : LED TURN ON one by one from Left to Right
            if (i < 8)
            {
                PORTD = (PORTD << 1) | 0x01;
            }
            // Pattern 2 : LED TURN OFF one by one from Left to Right
            else if (i < 16)
            {
                PORTD = PORTD << 1;
            }
            //Pattern 3 : LED TURN ON one by one from Right to Left
            else if (i < 24)
            {
                PORTD = (PORTD >> 1) | 0x80;
            }
            ////Pattern 4 : LED TURN OFF one by one from Right to Left
            else if (i < 32)
            {
                PORTD = PORTD >> 1;
            }

            i++;

            if (i == 32)
            {
                i = 0;
                PORTD = 0x00;
            }
        }
    }
}